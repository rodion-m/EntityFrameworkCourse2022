﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using Wpf.Ui.Common;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace SimpleJournal;

/// <summary>
/// Interaction logic for StudentsPage.xaml
/// </summary>
public partial class StudentsPage
{
    public ObservableRangeCollection<Student> Students { get; } = new();
    public ObservableRangeCollection<Group> Groups { get; } = new();
    
    public Student CurrentStudent { get; set; } = new();
    public Group CurrentGroup { get; set; } = new();

    private AppDbContext _db = null!;
    private bool _isUnloaded;

    public StudentsPage()
    {
        InitializeComponent();
    }
    
    private async void Page_Loaded(object sender, RoutedEventArgs e)
    {
        await LoadDatabaseAndConnect();
        
        List<Student> students = await _db.Students
            .OrderBy(it => it.Name)
            .Include(s => s.Group)
            .Include(s => s.Visits)
            .ToListAsync();
        List<Group> groups = await _db.Groups
            .AsNoTracking() //EF, забудь про эти записи
            .ToListAsync();

        Groups.ReplaceRange(groups);
        Students.ReplaceRange(students);

        progressRing.Visibility = Visibility.Collapsed;
        studentsDataGrid.Visibility = Visibility.Visible;
        _isUnloaded = false;
    }

    private async Task LoadDatabaseAndConnect()
    {
        _db = new AppDbContext();
        await Task.Run(() => _db.Database.CanConnectAsync());
    }

    private void Page_Unloaded(object sender, RoutedEventArgs e)
    {
        _db.Dispose();
        _isUnloaded = true;
    }

    private async void Students_CurrentCellChanged(object sender, EventArgs e)
    {
        if (_isUnloaded) return;
        CurrentStudent = (studentsDataGrid.SelectedItem as Student) ?? new Student();
        await SaveChangesAsync();
    }

    private void Students_PreviewCanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
        if (e.Command == DataGrid.DeleteCommand)
        {
            var dataGrid = (DataGrid)sender;
            var item = (Student) dataGrid.SelectedItem;
            _db.Students.Remove(item);
        }
    }

    private async void Students_AddingNewItem(object sender, AddingNewItemEventArgs e)
    {
        var newItem = new Student(Guid.NewGuid(), "Без имени");
        e.NewItem = newItem;
        await _db.Students.AddAsync(newItem);
    }

    private async void AddStudent(object sender, RoutedEventArgs e)
    {
        var student = new Student(Guid.NewGuid(), nameTextBox.Text)
        {
            EducationCost = (int) educationCostNumberBox.Value,
            Phone = phoneTextBox.Text,
            Group = (Group) groupComboBox.SelectedItem
        };
        _db.Entry(student.Group).State = EntityState.Detached;
        await _db.Students.AddAsync(student);
        Students.Add(student);
        await _db.SaveChangesAsync();
        MessageBox.Show("Запись добавлена");
        // var newStudent = CurrentStudent with { Id = Guid.NewGuid()};
        // _db.Entry(CurrentStudent).State = EntityState.Unchanged;
        // await _db.Students.AddAsync(newStudent);
        // Students.Add(newStudent);
        // await _db.SaveChangesAsync();
    }

    private async void SaveChanges_Click(object sender, RoutedEventArgs e)
    {
        await SaveChangesAsync();
    }
    private async Task SaveChangesAsync()
    {
        var changesEntriesCount = await _db.SaveChangesAsync();
        if (changesEntriesCount > 0)
        {
            await App.Snackbar.ShowAsync("Оповещение", "Изменения сохранены", SymbolRegular.Save24);
        }
    }

    private void StudentsDataGrid_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        var student = studentsDataGrid.CurrentItem as Student;
        if (student == null) return; 
        nameTextBox.Text = student.Name;
        phoneTextBox.Text = student.Phone;
        educationCostNumberBox.Text = student.EducationCost.ToString();
        groupComboBox.SelectedItem = student.Group;
        //foreach (var group in groupComboBox.ItemsSource.Cast<Group>())
        //{
        //    if (group.Equals(student.Group))
        //    {
        //        ;
        //    }
        //}
    }

    private void SelectedGroupChanged(object sender, SelectionChangedEventArgs e)
    {
        //CurrentStudent.Group = (groupComboBox.SelectedItem as Group);
    }
}
